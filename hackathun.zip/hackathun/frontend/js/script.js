async function BuscarCadastros() {
    const nomeUser = document.getElementById('nomeInput').value;
     buscarCadastrosPorNome(nomeUser);
}

async function buscarCadastrosPorNome(nomeUser) {
    try {
        const response = await fetch(`http://localhost:5128/cadastro/BuscarPorNome?nome=${nomeUser}`);
        const data = await response.json();
     //   const tableBody = document.getElementById('tabela'); 

        console.log(data)
        console.log(response)
     ///   const tableBody = document.getElementById('tabela'); 

     if (data && data.length > 0) {
        if (nomeUser == nomeUser) { 
            console.log("Foi")
            window.location.replace("fase1.html");
        }
        }else {
            alert("Esse Cadastro não existe, volte para cadastrar para cadastrar")
            //console.log('entrou else')
           // tableBody.
            //innerHTML = '<tr><th colspan="5">Nenhum contato encontrado.</th></tr>';
       }
    } catch (error) {
        console.error('Erro ao buscar dados:', error);
    }
};


function adicionarCadastro() {
    Swal.fire({
        title: 'Novo Cadastro',
        html:
            '<input id="nomeUser" class="swal2-input" placeholder="Nome">' +
            '<input id="senhaUser" class="swal2-input" placeholder="Senha">' +
            '<input id="emailUser" class="swal2-input" placeholder="Email">' +
            '<input id="paisUser" class="swal2-input" placeholder="País">' +
            '<input id="telefone" class="swal2-input" placeholder="Telefone">',
        focusConfirm: false,
        preConfirm: () => {
            const nomeUser = Swal.getPopup().querySelector('#nomeUser').value;
            const senhaUser = Swal.getPopup().querySelector('#senhaUser').value;
            const emailUser = Swal.getPopup().querySelector('#emailUser').value;
            const paisUser = Swal.getPopup().querySelector('#paisUser').value;
            const telefone = Swal.getPopup().querySelector('#telefone').value;

            fetch('http://localhost:5128/cadastro', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    nomeUser: nomeUser,
                    senhaUser: senhaUser,
                    emailUser: emailUser,
                    paisUser: paisUser,
                    telefone: telefone
                })
            })
               .then(response => response.json())
               .then(data => {
                    const successModal = document.getElementById('successModal');
                    successModal.showModal();
                })
                .catch(error => {
                    console.error('Erro ao salvar dados:', error);
                });

        }
    });
}

function fecharModal() {
    const modal = document.getElementById('successModal');
    modal.close();
    AtualizarPagina()
}

function AtualizarPagina() {
    window.location.href = window.location.href; 
}