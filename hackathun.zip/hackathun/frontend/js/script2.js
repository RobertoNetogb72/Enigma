const fases = [
    { pergunta: "?", resposta: "74" },
    // Adicione mais fases aqui conforme necessário
];
 
let faseAtual = 0;
 
function verificarResposta() {
    const resposta = document.getElementById("respostaInput").value.toLowerCase();
   
    if (resposta === fases[faseAtual].resposta) {
      

        faseAtual++;
       
        if (faseAtual < fases.length) {
            
            // Redirecionar para a próxima página
            window.location.href = `fase${faseAtual + 1}.html`;
        } else {    
            logado();
            // Redirecionar para a página de conclusão ou página inicial
         //window.location.href = "fase2.html"; // ou qualquer outra página
        }
    } else {
        erro()
        //const mensagemErro = document.createElement("p");
        //mensagemErro.textContent = "Resposta incorreta. Tente novamente.";
        //mensagemErro.classList.add("mensagem-erro");
        //document.body.appendChild(mensagemErro);
    }
}
 
function enviarResposta() {
    verificarResposta();
}

function dica() {
    Swal.fire({
        title: "Dificuldade Para Achar Informação?",
        text: "Lembre-se que algo pode estar escondido",
        icon: "question",

      });
}

function logado(){
    Swal.fire({
        title: "Parabéns",
        text: "Você Conclui-o A Fase!! ",
        icon: "success",
        confirmButtonText: '<a href="fase3.html" class="fa fa-thumbs-up">Próxima Fase</a>'
    })

}
 function erro() {
    Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Resposta Errada, Tente Novamente!!!",

      });
 }