const fases = [
    { pergunta: "?", resposta: "74" },
    // Adicione mais fases aqui conforme necessário
];
 
let faseAtual = 0;
 
function verificarResposta() {
    const resposta = document.getElementById("respostaInput").value.toLowerCase();
   
    if (resposta === fases[faseAtual].resposta) {
        alert("Resposta correta! Avance para a próxima fase.");
        faseAtual++;
       
        if (faseAtual < fases.length) {
            // Redirecionar para a próxima página
            window.location.href = `fase${faseAtual + 1}.html`;
        } else {
            // Redirecionar para a página de conclusão ou página inicial
            window.location.href = "fase3.html"; // ou qualquer outra página
        }
    } else {
        const mensagemErro = document.createElement("p");
        mensagemErro.textContent = "Resposta incorreta. Tente novamente.";
        mensagemErro.classList.add("mensagem-erro");
        document.body.appendChild(mensagemErro);
    }
}
 
function enviarResposta() {
    verificarResposta();
}