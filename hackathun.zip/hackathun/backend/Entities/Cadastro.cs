using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace backend.Entities
{
    public class Cadastro
    {
        public int Id { get; set; }
        public string NomeUser { get; set; }
        public string SenhaUser { get; set; }
        public string EmailUser { get; set; }
        public string PaisUser { get; set; }
        public string Telefone { get; set; }


    }
}