using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using backend.Entities;

namespace backend.Context
{
    public class EnigmaDBContext : DbContext
    {
        //receber configuração conexao com o banco , passando na classe pai(DbContext) o  options 
        public EnigmaDBContext(DbContextOptions<EnigmaDBContext> options) : base(options)
        { }


        //vai representar uma tabela do banco
        public DbSet<Cadastro> Cadastros { get; set; }
    }


}