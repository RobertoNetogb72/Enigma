using Microsoft.AspNetCore.Mvc;
using backend.Context;
using backend.Entities;

namespace backend.Controllers
{



    [ApiController]
    [Route("cadastro")]
    public class CadastroController : ControllerBase
    {
        //criar atributo privado somente para leitura
        private readonly EnigmaDBContext _enigmadbcontext;


        //criar construtor para receber context
        public CadastroController(EnigmaDBContext context)
        {
            _enigmadbcontext = context;
        }


        [HttpPost]
        public IActionResult Create(Cadastro cadastro)
        {

            _enigmadbcontext.Add(cadastro);
            _enigmadbcontext.SaveChanges();
            //  return Ok(contato);

            //retorna a rota que ele pode utilizar (endereço url que foi criado)
            return CreatedAtAction(nameof(BuscarPorId), new { id = cadastro.Id }, cadastro);
        }

        [HttpGet("{id}")]
        public IActionResult BuscarPorId(int id)
        {
            var cadastro = _enigmadbcontext.Cadastros.Find(id);

            if (cadastro == null)
                return NotFound();

            return Ok(cadastro);
        }

        [HttpGet("BuscarPorNome")]
        public IActionResult BuscarPorNome(string nome)
        {
            var cadastros = _enigmadbcontext.Cadastros.Where(x => x.NomeUser.Contains(nome));
            return Ok(cadastros);

        }

        [HttpGet("BuscarPorSenha")]
        public IActionResult BuscarPorSenha(string senha)
        {
            var cadastros = _enigmadbcontext.Cadastros.Where(x => x.SenhaUser.Contains(senha));
            return Ok(cadastros);

        }
    
    }    

    }
